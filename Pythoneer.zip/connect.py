import pyodbc

conn_str = ("Driver={SQL Server Native Client 11.0};"
            "Server=mskl-db-server.database.windows.net;"
            "Database=tigeranalytics;"
            "UID=tigerlearner;"
            "PWD=AsDf1234;")
conn = pyodbc.connect(conn_str)