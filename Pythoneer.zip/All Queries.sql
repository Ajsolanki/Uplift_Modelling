-- Number of orders having unusual discounts as per 6 dimensions of data quality?
select count(order_id) as unsual_dis from marketing_transaction
where grand_total <=0 and discount_amount>0

-- Minimum of "qty_ordered" column among one time orders placed by customers?
select min(min_ords) as min_qty_ord 
from (SELECT trans.customer_id, min(trans.qty_ordered) as min_ords
  FROM marketing_transaction trans 
  INNER join marketing_orders ord on trans.order_id = ord.order_id
  GROUP by trans.customer_id
  HAVING count(trans.order_id)=1) A
  
-- SELECT TOP 100 trans.customer_id, min(trans.qty_ordered) as min_ords
--   FROM [dbo].[marketing_transaction] trans 
--   INNER join marketing_orders ord on trans.order_id = ord.order_id
--   GROUP by trans.customer_id
--   HAVING count(trans.order_id)=1
--   order by min_ords desc


-- Let's check which 5 customers are prime regular customers for each segment according to their placing orders. 
SELECT  B.category, B.customer_name, B.total_orders
FROM
(
	SELECT  A.category_name AS category
	       ,cust.name       AS customer_name
	       ,A.qty           AS total_orders
	       ,Row_NUMBER() OVER(PARTITION BY A.category_name ORDER BY A.qty DESC) RNum
	FROM
	(
		SELECT  category_name
		       ,customer_id
		       ,COUNT(ord.order_id) AS qty
		FROM marketing_orders ord
		GROUP BY  category_name
		         ,customer_id
	) A
	INNER JOIN marketing_customer cust
	ON A.customer_id = cust.customer_id
) B
WHERE B.RNum <= 5 

-- It’s a big deal to know which product’s demand is more in each category among our customers. So we can analyze which product gives us more sales. 
-- !!--- Sales and qty based on total orders placed ---!!
-- SELECT ord.category_name, 
-- 	count(ord.order_id) AS qty,
--     sum(trans.grand_total) AS sales
-- FROM marketing_orders ord
-- INNER JOIN marketing_transaction trans ON ord.order_id = trans.order_id 
-- GROUP BY ord.category_name
-- ORDER BY qty DESC, sales DESC

--!!--- Sales and total qty based on total products orders in orders ---!!
SELECT TOP 100 ord.category_name AS category,
 sum(trans.qty_ordered) AS qty, 
 sum(trans.grand_total) AS sales
from  marketing_transaction trans
INNER JOIN marketing_orders ord ON trans.order_id = ord.order_id 
where qty_ordered>=0
GROUP BY ord.category_name
ORDER BY sales DESC


-- Is there any city that comes in the red zone for late delivery? Redzone is defined when avg delay hr> overall avg delay hrs
with city_table AS (SELECT ord.order_id, cust.city,
DATEDIFF(HOUR, order_estimated_delivery_date, order_customer_delivery_date) as diff
FROM marketing_orders ord 
INNER JOIN marketing_customer cust ON ord.customer_id = cust.customer_id
)

select A.*,
case when avg_delay_hrs> overall_avg_delay_hrs then 'yes' else 'no' END as red_zone FROM
(SELECT city, 
AVG(city_table.diff) as avg_delay_hrs, (select AVG(city_table.diff) from city_table WHERE city_table.diff>=0) as overall_avg_delay_hrs
 FROM city_table
WHERE city_table.diff>=0
GROUP BY city_table.city) A