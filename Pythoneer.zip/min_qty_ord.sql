select min(min_ords) as min_qty_ord 
from (SELECT trans.customer_id, min(trans.qty_ordered) as min_ords
  FROM marketing_transaction trans 
  INNER join marketing_orders ord on trans.order_id = ord.order_id
  GROUP by trans.customer_id
  HAVING count(trans.order_id)=1) A
  
-- SELECT TOP 100 trans.customer_id, min(trans.qty_ordered) as min_ords
--   FROM [dbo].[marketing_transaction] trans 
--   INNER join marketing_orders ord on trans.order_id = ord.order_id
--   GROUP by trans.customer_id
--   HAVING count(trans.order_id)=1
--   order by min_ords desc